﻿namespace GB_Eater
{
    partial class GB_EATER
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GB_EATER));
            btnLoad = new Button();
            btnProtect = new Button();
            btnSave = new Button();
            cmbMode = new ComboBox();
            panelPreview = new Panel();
            picProtected = new PictureBox();
            picOriginal = new PictureBox();
            sliderStrength = new TrackBar();
            chkWatermark = new CheckBox();
            txtWatermark = new TextBox();
            trackOpacity = new TrackBar();
            label1 = new Label();
            panelPreview.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)picProtected).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picOriginal).BeginInit();
            ((System.ComponentModel.ISupportInitialize)sliderStrength).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackOpacity).BeginInit();
            SuspendLayout();
            // 
            // btnLoad
            // 
            btnLoad.Location = new Point(127, 99);
            btnLoad.Name = "btnLoad";
            btnLoad.Size = new Size(145, 53);
            btnLoad.TabIndex = 0;
            btnLoad.Text = "Load";
            btnLoad.UseVisualStyleBackColor = true;
            btnLoad.Click += btnLoad_Click;
            // 
            // btnProtect
            // 
            btnProtect.Location = new Point(481, 99);
            btnProtect.Name = "btnProtect";
            btnProtect.Size = new Size(145, 53);
            btnProtect.TabIndex = 1;
            btnProtect.Text = "Protecc";
            btnProtect.UseVisualStyleBackColor = true;
            btnProtect.Click += btnProtect_Click;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(833, 99);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(145, 53);
            btnSave.TabIndex = 2;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // cmbMode
            // 
            cmbMode.FormattingEnabled = true;
            cmbMode.Items.AddRange(new object[] { "Soft - Light luminance noise (very safe visually)", "Balanced - Noise + edge jitter (recommended)", "Strong - Noise + edge + texture disruption" });
            cmbMode.Location = new Point(127, 494);
            cmbMode.Name = "cmbMode";
            cmbMode.Size = new Size(312, 28);
            cmbMode.TabIndex = 3;
            // 
            // panelPreview
            // 
            panelPreview.AutoScroll = true;
            panelPreview.Controls.Add(picProtected);
            panelPreview.Location = new Point(552, 172);
            panelPreview.Name = "panelPreview";
            panelPreview.Size = new Size(549, 413);
            panelPreview.TabIndex = 5;
            panelPreview.TabStop = true;
            // 
            // picProtected
            // 
            picProtected.BackColor = SystemColors.ActiveBorder;
            picProtected.Image = (Image)resources.GetObject("picProtected.Image");
            picProtected.Location = new Point(0, 11);
            picProtected.Name = "picProtected";
            picProtected.Size = new Size(546, 402);
            picProtected.TabIndex = 7;
            picProtected.TabStop = false;
            // 
            // picOriginal
            // 
            picOriginal.BackColor = SystemColors.ActiveCaption;
            picOriginal.Image = (Image)resources.GetObject("picOriginal.Image");
            picOriginal.Location = new Point(127, 172);
            picOriginal.Name = "picOriginal";
            picOriginal.Size = new Size(312, 270);
            picOriginal.SizeMode = PictureBoxSizeMode.Zoom;
            picOriginal.TabIndex = 6;
            picOriginal.TabStop = false;
            // 
            // sliderStrength
            // 
            sliderStrength.Location = new Point(127, 572);
            sliderStrength.Name = "sliderStrength";
            sliderStrength.Size = new Size(312, 56);
            sliderStrength.TabIndex = 7;
            // 
            // chkWatermark
            // 
            chkWatermark.AutoSize = true;
            chkWatermark.Location = new Point(746, 604);
            chkWatermark.Name = "chkWatermark";
            chkWatermark.Size = new Size(133, 24);
            chkWatermark.TabIndex = 8;
            chkWatermark.Text = "Add watermark";
            chkWatermark.UseVisualStyleBackColor = true;
            chkWatermark.CheckedChanged += chkWatermark_CheckedChanged;
            // 
            // txtWatermark
            // 
            txtWatermark.Location = new Point(699, 696);
            txtWatermark.Name = "txtWatermark";
            txtWatermark.Size = new Size(217, 27);
            txtWatermark.TabIndex = 9;
            txtWatermark.Text = "© AriyaKonsuay";
            txtWatermark.TextChanged += txtWatermark_TextChanged;
            // 
            // trackOpacity
            // 
            trackOpacity.Location = new Point(642, 634);
            trackOpacity.Maximum = 100;
            trackOpacity.Name = "trackOpacity";
            trackOpacity.Size = new Size(336, 56);
            trackOpacity.TabIndex = 10;
            trackOpacity.TickFrequency = 10;
            trackOpacity.Value = 25;
            trackOpacity.Scroll += trackOpacity_Scroll;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(32, 703);
            label1.Name = "label1";
            label1.Size = new Size(40, 20);
            label1.TabIndex = 11;
            label1.Text = "V.0.1";
            // 
            // GB_EATER
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1139, 748);
            Controls.Add(label1);
            Controls.Add(trackOpacity);
            Controls.Add(txtWatermark);
            Controls.Add(chkWatermark);
            Controls.Add(sliderStrength);
            Controls.Add(picOriginal);
            Controls.Add(panelPreview);
            Controls.Add(cmbMode);
            Controls.Add(btnSave);
            Controls.Add(btnProtect);
            Controls.Add(btnLoad);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "GB_EATER";
            Text = "GoodBoi_Watermark_adder_n_mini_AI_EATER";
            Load += Form1_Load;
            panelPreview.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)picProtected).EndInit();
            ((System.ComponentModel.ISupportInitialize)picOriginal).EndInit();
            ((System.ComponentModel.ISupportInitialize)sliderStrength).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackOpacity).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnLoad;
        private Button btnProtect;
        private Button btnSave;
        private ComboBox cmbMode;
        private Panel panelPreview;
        private PictureBox picOriginal;
        private PictureBox picProtected;
        private TrackBar sliderStrength;
        private CheckBox chkWatermark;
        private TextBox txtWatermark;
        private TrackBar trackOpacity;
        private Label label1;
    }
}
