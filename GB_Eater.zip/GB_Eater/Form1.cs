using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace GB_Eater
{
    public partial class GB_EATER : Form
    {
       
        Bitmap? originalImage;
        Bitmap? protectedImage;

        float zoom = 1.0f;

        enum ProtectMode
        {
            Soft = 0,
            Balanced = 1,
            Strong = 2
        }

        public GB_EATER()
        {
            InitializeComponent();
            this.Text = " GoodBoi Watermark adder 'n mini AI_EATER";
            cmbMode.SelectedIndex = 1; // Balanced default
        }

        // ================= IMAGE LOAD / SAVE =================

        private void btnLoad_Click(object sender, EventArgs e)
        {
            using OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Images|*.png;*.jpg;*.jpeg;*.bmp";

            if (ofd.ShowDialog() != DialogResult.OK) return;

            string path = ofd.FileName;
            byte[] bytes = File.ReadAllBytes(path);
            using var ms = new MemoryStream(bytes);
            originalImage?.Dispose();
            originalImage = new Bitmap(ms); // now file not locked
            picOriginal.Image = originalImage;

            ResetZoom();
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (protectedImage == null) return;

            using SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "PNG Image|*.png|JPEG Image|*.jpg";

            if (sfd.ShowDialog() != DialogResult.OK) return;

            ImageFormat fmt = sfd.FileName.EndsWith(".jpg") ? ImageFormat.Jpeg : ImageFormat.Png;
            originalImage?.Dispose();
            originalImage = null; // free file lock before overwrite
            SafeSave(protectedImage, sfd.FileName, fmt);
        }

        // ================= PROTECT =================
        Bitmap? protectedBaseImage;   // image without watermark
        private void btnProtect_Click(object sender, EventArgs e)
        {
            if (originalImage == null)
            {
                MessageBox.Show("Please load an image first.");
                return;
            }

            int strength = sliderStrength.Value;
            int opabar = trackOpacity.Value;

            ProtectMode mode = (ProtectMode)cmbMode.SelectedIndex;

            protectedBaseImage?.Dispose();
            protectedBaseImage = ProtectImage(originalImage, strength, mode);

            UpdateWatermarkPreview();

            if (!chkWatermark.Checked)
            {
                protectedImage = new Bitmap(protectedBaseImage);
            }
            else
            {
                float opacity = trackOpacity.Value / 100f;

                protectedImage = ApplyTiledCircularWatermark(
                    protectedBaseImage,
                    txtWatermark.Text,
                    opacity,
                    300,    // tile size (spacing)
                     16      // text count per circle
                );
            }


            picProtected.Image = protectedImage;
            ResetZoom();
            CenterImage();
        }

        Bitmap ProtectImage(Bitmap src, int strength, ProtectMode mode) // after apply watermark and noise
        {
            Bitmap result = new Bitmap(src);
            Random rng = new Random(Guid.NewGuid().GetHashCode());

            switch (mode)
            {
                case ProtectMode.Soft:
                    result = ApplyBalancedNoise(result, strength / 2, rng);
                    break;

                case ProtectMode.Balanced:
                    result = ApplyBalancedNoise(result, strength, rng);
                    result = EdgeJitter(result, strength / 2);
                    break;

                case ProtectMode.Strong:
                    result = ApplyBalancedNoise(result, strength, rng);
                    result = EdgeJitter(result, strength);
                    result = TextureNoise(result, strength / 2, rng);
                    break;
            }

            return result;
        }

        // ================= Watermark =================
        Bitmap ApplyTiledCircularWatermark(
        Bitmap src,
        string text,
        float opacity,
        int tileSize,
        int repeatPerCircle
)
        {

            void DrawCircularText(
        Graphics g,
        string text,
         Font font,
        Brush brush,
        float cx,
        float cy,
        float radius,
        int repeat
)
            {
                for (int i = 0; i < repeat; i++)
                {
                    float angle = 360f / repeat * i;

                    g.TranslateTransform(cx, cy);
                    g.RotateTransform(angle);
                    g.TranslateTransform(0, -radius);

                    SizeF size = g.MeasureString(text, font);
                    g.DrawString(text, font, brush, -size.Width / 2, -size.Height / 2);

                    g.ResetTransform();
                }
            }
            Bitmap bmp = new Bitmap(src.Width, src.Height, PixelFormat.Format32bppArgb);

            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                g.DrawImage(src, 0, 0);

                using Font font = new Font(
                    "Arial",
                    Math.Max(12, src.Width / 40f),
                    FontStyle.Bold
                );

                using SolidBrush brush = new SolidBrush(
                    Color.FromArgb((int)(opacity * 255), Color.White)
                );

                float radius = tileSize * 0.35f;

                for (int ty = 0; ty < src.Height + tileSize; ty += tileSize)
                {
                    for (int tx = 0; tx < src.Width + tileSize; tx += tileSize)
                    {
                        // Offset every other row (tile pattern)
                        float cx = tx + (ty / tileSize % 2 == 0 ? tileSize / 2f : 0);
                        float cy = ty;

                        DrawCircularText(
                            g,
                            text,
                            font,
                            brush,
                            cx,
                            cy,
                            radius,
                            repeatPerCircle
                        );
                    }
                }
            }

            return bmp;
        }
        Bitmap ApplyWatermark(Bitmap src, string text, float opacity) //one simple line 
        {
            Bitmap bmp = new Bitmap(src.Width, src.Height, PixelFormat.Format32bppArgb);

            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.DrawImage(src, 0, 0);

                using Font font = new Font("Arial", src.Width / 20f, FontStyle.Bold);
                using SolidBrush brush = new SolidBrush(
                    Color.FromArgb((int)(opacity * 255), 255, 255, 255)
                );

                SizeF size = g.MeasureString(text, font);

                PointF pos = new PointF(
                    src.Width - size.Width - 20,
                    src.Height - size.Height - 20
                );

                g.DrawString(text, font, brush, pos);
            }

            return bmp;
        }
        Bitmap ApplyCircularWatermark(Bitmap src, string text, float opacity) //Circular one
        {
            Bitmap bmp = new Bitmap(src.Width, src.Height, PixelFormat.Format32bppArgb);

            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                g.DrawImage(src, 0, 0);

                using Font font = new Font("Arial", Math.Max(14, src.Width / 30f), FontStyle.Bold);
                using SolidBrush brush = new SolidBrush(
                    Color.FromArgb((int)(opacity * 255), Color.White)
                );

                float cx = src.Width / 2f;
                float cy = src.Height / 2f;

                
                int repeat = 24; // number of texts around circle : 24 default

                for (int i = 0; i < repeat; i++)
                {
                    float angle = 360f / repeat * i;

                    g.TranslateTransform(cx, cy);
                    g.RotateTransform(angle);
                    

                    SizeF size = g.MeasureString(text, font);
                    g.DrawString(text, font, brush, -size.Width / 2, -size.Height / 2);

                    g.ResetTransform();
                }
            }

            return bmp;
        }

        void UpdateWatermarkPreview()  //quick preview update dont need to re-appllied for new one
        {
            protectedImage?.Dispose();

            if (protectedBaseImage == null)
            {
                protectedImage = null;
                picProtected.Image = null;
                return;
            }

            if (!chkWatermark.Checked)
            {
                protectedImage = new Bitmap(protectedBaseImage);
            }
            else
            {
                float opacity = trackOpacity.Value / 100f;

                protectedImage = ApplyCircularWatermark(
                    protectedBaseImage,
                    txtWatermark.Text,
                    opacity
                );
            }

            picProtected.Image = protectedImage;
        }

        // ================= PROTECTION LAYERS =================

        Bitmap ApplyBalancedNoise(Bitmap src, int strength, Random rng)
        {
            Bitmap bmp = new Bitmap(src.Width, src.Height);

            for (int y = 0; y < src.Height; y++)
                for (int x = 0; x < src.Width; x++)
                {
                    Color c = src.GetPixel(x, y);
                    // Skip pixels that are completely transparent
                    if (c.A == 0)
                    {
                        bmp.SetPixel(x, y, Color.Transparent);
                        continue;
                    }

                    int lum = (int)(0.299 * c.R + 0.587 * c.G + 0.114 * c.B);
                    int noise = rng.Next(-strength, strength + 1);
                    int newLum = Clamp(lum + noise);

                    float ratio = lum == 0 ? 1f : (float)newLum / lum;

                    bmp.SetPixel(x, y, Color.FromArgb(
                        Clamp((int)(c.R * ratio)),
                        Clamp((int)(c.G * ratio)),
                        Clamp((int)(c.B * ratio))
                    ));
                }
            return bmp;

        }

        Bitmap EdgeJitter(Bitmap src, int strength)
        {
            Bitmap bmp = new Bitmap(src);

            for (int y = 1; y < bmp.Height - 1; y++)
                for (int x = 1; x < bmp.Width - 1; x++)
                {
                    if ((x + y) % 4 != 0) continue;

                    Color c = bmp.GetPixel(x, y);
                    bmp.SetPixel(x + 1, y, c);
                }
            return bmp;
        }

        Bitmap TextureNoise(Bitmap src, int strength, Random rng)
        {
            Bitmap bmp = new Bitmap(src);

            for (int y = 0; y < bmp.Height; y++)
                for (int x = 0; x < bmp.Width; x++)
                {

                    if ((x + y) % 3 != 0) continue;

                    int n = rng.Next(-strength, strength + 1);
                    Color c = src.GetPixel(x, y);
                    // Skip pixels that are completely transparent for png
                    if (c.A == 0)
                    {
                        bmp.SetPixel(x, y, Color.Transparent);
                        continue;
                    }

                    bmp.SetPixel(x, y, Color.FromArgb(
                        Clamp(c.R + n),
                        Clamp(c.G + n),
                        Clamp(c.B + n)
                    ));
                }
            return bmp;
        }

        // ================= VIEW =================

        protected override void OnMouseWheel(MouseEventArgs e) // for fuck sake zooming with mousewheel for later update if I'm not lazy
        {
            if (protectedImage == null) return;

            Point p = panelPreview.PointToClient(Cursor.Position);
            if (!panelPreview.ClientRectangle.Contains(p)) return;

            zoom += e.Delta > 0 ? 0.1f : -0.1f;
            zoom = Math.Max(0.2f, Math.Min(6f, zoom));

            picProtected.Width = (int)(protectedImage.Width * zoom);
            picProtected.Height = (int)(protectedImage.Height * zoom);
        }

        void ResetZoom()
        {
            zoom = 1.0f;
            if (protectedImage != null)
            {
                picProtected.Width = protectedImage.Width;
                picProtected.Height = protectedImage.Height;
            }
        }

        void CenterImage()
        {
            picProtected.Left = Math.Max(0, (panelPreview.Width - picProtected.Width) / 2);
            picProtected.Top = Math.Max(0, (panelPreview.Height - picProtected.Height) / 2);
        }

        int Clamp(int v) => Math.Max(0, Math.Min(255, v));

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        // C#
        private void SafeSave(Bitmap bmp, string destPath, ImageFormat fmt)
        {
            string tmp = Path.GetTempFileName();
            try
            {
                bmp.Save(tmp, fmt);               // write to temp first
                if (File.Exists(destPath)) File.Delete(destPath); // ensure overwrite
                File.Move(tmp, destPath);         // atomic-ish replace
            }
            catch (Exception ex)
            {
                // log ex.ToString() somewhere visible for debugging I have't use them yet.
                throw;
            }
            finally
            {
                if (File.Exists(tmp)) File.Delete(tmp);
            }
        }

        private void trackOpacity_Scroll(object sender, EventArgs e)
        {
            if (protectedBaseImage == null) return;
            UpdateWatermarkPreview();
        }

        private void chkWatermark_CheckedChanged(object sender, EventArgs e)
        {
            if (protectedBaseImage == null) return;
            UpdateWatermarkPreview();
        }

        private void txtWatermark_TextChanged(object sender, EventArgs e)
        {
            if (protectedBaseImage == null) return;
            UpdateWatermarkPreview();
        }
    }
}
